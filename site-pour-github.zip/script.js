function navigateToPage(pageUrl) {
  window.location.href = pageUrl;
}